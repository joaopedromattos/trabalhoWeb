function redirectTodoPage() {
  console.log('Teste');
  window.location('/');
}
